# dqn_visual_final_lastreward_fixed.py
import torch
import torch.nn as nn
import torch.optim as optim
import numpy as np
import pandas as pd
import random
import matplotlib.pyplot as plt
from rocket_env import SimpleRocketEnv
import time

# === DQN Model ===
class DQN(nn.Module):
    def __init__(self, state_dim, action_dim):
        super(DQN, self).__init__()
        self.net = nn.Sequential(
            nn.Linear(state_dim, 128), nn.ReLU(),
            nn.Linear(128, 128), nn.ReLU(),
            nn.Linear(128, action_dim)
        )

    def forward(self, x):
        return self.net(x)

# === Load Manual Data untuk Replay Buffer Awal ===
def load_manual_data(csv_path="manual_data.csv", env=None):
    data = pd.read_csv(csv_path)
    states = data[["x","y","vx","vy","sin_theta","cos_theta","omega","dx","dy"]].values
    actions = data["action"].values
    rewards = data["reward"].values
    dones = data["done"].values.astype(np.bool_)

    # next_states = shift satu step
    next_states = np.roll(states, -1, axis=0)

    # normalisasi jika env diberikan
    if env is not None:
        states = states / env._normalizer()
        next_states = next_states / env._normalizer()

    return states, actions, rewards, next_states, dones

# === Training DQN dengan Visualisasi ===
def train_dqn(episodes=50, lr=1e-3, gamma=0.95, epsilon_start=1.0,
              epsilon_end=0.05, epsilon_decay=0.98):

    env = SimpleRocketEnv(render_mode="human")
    state_dim = 9
    action_dim = env.action_space.n

    model = DQN(state_dim, action_dim)
    optimizer = optim.Adam(model.parameters(), lr=lr)
    criterion = nn.MSELoss()

    states, actions, rewards_manual, next_states, dones = load_manual_data("manual_data.csv", env)
    replay_buffer = list(zip(states, actions, rewards_manual, next_states, dones))

    episode_rewards = []
    epsilon = epsilon_start
    episode_hit_target = []  # indikator roket kena target

    for ep in range(1, episodes + 1):
        state, _ = env.reset()
        state = state / env._normalizer()
        done = False
        total_reward = 0
        step = 0
        last_reward = 0
        hit_target = False

        # ambil radius target aman
        target_radius = getattr(env, "target_radius", 0.1)  # default jika env tidak punya

        while not done:
            state_tensor = torch.tensor([state], dtype=torch.float32)
            if random.random() < epsilon:
                action = env.action_space.sample()
            else:
                with torch.no_grad():
                    q_vals = model(state_tensor)
                    action = torch.argmax(q_vals, dim=1).item()

            next_state, reward_env, terminated, truncated, _ = env.step(action)
            next_state_norm = next_state / env._normalizer()

            # koordinat roket & target (denormalisasi)
            x, y = next_state[:2] * env._normalizer()[:2]
            tx, ty = env.target_pos
            distance = np.linalg.norm([x - tx, y - ty])

            # reward manual dari CSV
            if step < len(rewards_manual):
                last_reward = rewards_manual[min(step, len(rewards_manual)-1)]

            reward = last_reward
            total_reward += reward
            step += 1
            done_flag = terminated or truncated

            # ===== cek roket benar-benar kena target =====
            if distance <= target_radius:
                hit_target = True

            replay_buffer.append((state, action, reward, next_state_norm, done_flag))
            if len(replay_buffer) > 10000:
                replay_buffer.pop(0)

            if len(replay_buffer) >= 64:
                batch = random.sample(replay_buffer, 64)
                s, a, r, ns, d = zip(*batch)
                s = torch.tensor(np.array(s), dtype=torch.float32)
                a = torch.tensor(a, dtype=torch.int64)
                r = torch.tensor(r, dtype=torch.float32)
                ns = torch.tensor(np.array(ns), dtype=torch.float32)
                d = torch.tensor(d, dtype=torch.float32)

                q_values = model(s)
                q_val = q_values.gather(1, a.unsqueeze(1)).squeeze(1)
                with torch.no_grad():
                    next_q = model(ns).max(1)[0]
                    target = r + gamma * next_q * (1 - d)

                loss = criterion(q_val, target)
                optimizer.zero_grad()
                loss.backward()
                optimizer.step()

            env.render()
            time.sleep(0.02)
            state = next_state_norm
            done = done_flag

        epsilon = max(epsilon * epsilon_decay, epsilon_end)
        episode_rewards.append(total_reward)
        episode_hit_target.append(hit_target)

        print(f"Episode {ep}/{episodes} | Reward (last step)={last_reward:.2f} | Hit Target={hit_target} | Epsilon: {epsilon:.2f}")

    env.close()

    # simpan model & rewards
    torch.save(model.state_dict(), "dqn_model_visual_final_lastreward.pth")
    np.save("training_rewards_visual_final_lastreward.npy", episode_rewards)
    np.save("episode_hit_target.npy", episode_hit_target)
    print("✅ Training selesai! Model, rewards & indikator target tersimpan.")

    # plot hasil training
    plt.figure(figsize=(8,4))
    plt.plot(range(1, episodes+1), episode_rewards, label="Episode Reward")
    plt.xlabel("Episode")
    plt.ylabel("Total Reward")
    plt.title("DQN Training Visualization (0–50 Episodes)")
    plt.grid(True)
    plt.legend()
    plt.show()


if __name__ == "__main__":
    train_dqn(episodes=50)
