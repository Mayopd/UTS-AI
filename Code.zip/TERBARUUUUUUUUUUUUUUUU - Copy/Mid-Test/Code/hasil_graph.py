# hasil_graph.py
import numpy as np
import matplotlib.pyplot as plt

rewards = np.load("training_rewards_visual.npy")

plt.figure(figsize=(8,5))
plt.plot(range(len(rewards)), rewards, color='blue', label="Average Reward per Episode")
plt.title("DQN Training Progress (0–50 Episodes)")
plt.xlabel("Episode")
plt.ylabel("Average Reward")
plt.grid(True)
plt.legend()
plt.show()
